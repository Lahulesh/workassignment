﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SecondAssignment
{
    public partial class Allocation : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=BookLibrary;Integrated Security=True");
        int AlloGrid = 0;
        public Allocation()
        {
            InitializeComponent();
        }

        private void Allocation_Load(object sender, EventArgs e)
        {
            textBox5.Enabled = false;
            repeat();
            con.Open();
            SqlCommand cmd = new SqlCommand("select BookName from bookdetails where BookId not in(select BookId from Allocation)", con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                this.comboBox2.Items.Add(reader["BookName"].ToString());
            }
            reader.Close();

            SqlCommand command2 = new SqlCommand("select  UserName from studentdetails ", con);
            SqlDataReader reader1 = command2.ExecuteReader();
            while (reader1.Read())
            {
                this.comboBox1.Items.Add(reader1["UserName"].ToString());
            }
            textBox3.Text = DateTime.UtcNow.ToString();
            textBox4.Text = DateTime.UtcNow.ToString();
            reader1.Close();
            con.Close();
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand("select  UserId from studentdetails  where UserName='" + comboBox1.Text +"'", con);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                textBox1.Text = reader["UserId"].ToString();
            }
            reader.Close();
            con.Close();
        }



        private void comboBox2_SelectedValueChanged(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand("select BookId from bookdetails where BookName='" + comboBox2.Text + "'", con);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                textBox2.Text = reader["BookId"].ToString();
            }
            reader.Close();
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string ret = "";
            SqlCommand cmd = new SqlCommand("insert into Allocation values('"+Convert.ToInt32(textBox1.Text)+ "','"+Convert.ToInt32(textBox2.Text)+"','" + comboBox1.Text+"','"+comboBox2.Text+"','"+Convert.ToDateTime(textBox3.Text)+"','"+ret+"')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Congratulation Data Inserted");
            repeat();
            con.Close();
            comboBox1.Text = "";
            comboBox2.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox5.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            reset();
        }
        void reset()
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if(dataGridView1.RowCount > 0)
            {
                var row = dataGridView1.CurrentRow;
                textBox5.Text = row.Cells[0].Value.ToString();
                textBox1.Text = row.Cells[1].Value.ToString();
                textBox2.Text = row.Cells[2].Value.ToString();
                comboBox1.Text = row.Cells[3].Value.ToString();
                comboBox2.Text = row.Cells[4].Value.ToString();
                textBox3.Text = row.Cells[5].Value.ToString();
                textBox4.Text = row.Cells[6].Value.ToString();
                if(Convert.ToDateTime(textBox4.Text) <= DateTime.Now.Date)
                {
                    AlloGrid++;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (AlloGrid == 1)
            {
                textBox4.Text = DateTime.UtcNow.ToString();
                con.Open();
                SqlCommand command = new SqlCommand("update Allocation set ReturnDate='"+textBox4.Text+"'where AllocationId ='"+Convert.ToInt32(textBox5.Text)+"'", con);
                command.ExecuteNonQuery();
                MessageBox.Show("Book Return");
                repeat();
                con.Close();
                reset();
            }
            else
            {
                MessageBox.Show("BOOK ALREADY RETURN");
            }
        }
        void repeat()
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Allocation", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = (ds.Tables[0]);
        }
    }
}
