﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SecondAssignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void userAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UserAccount us = new UserAccount();
            us.ShowDialog();
        }

        private void bookAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookDetails bd = new BookDetails();
            bd.ShowDialog();
        }

        private void mappingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Allocation al = new Allocation();
            al.ShowDialog();
        }
    }
}
