﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace SecondAssignment
{
    public partial class BookDetails : Form
    {
        int uname = 0;
        int aname = 0;
        int desc = 0;
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=BookLibrary;Integrated Security=True");
        public BookDetails()
        {
            InitializeComponent();
        }

        private void BookDetails_Load(object sender, EventArgs e)
        {
            uname = 0;
            aname = 0;
            desc = 0;
            button4.Enabled = false;
            button5.Enabled = false;
            textBox1.Enabled = false;
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from bookdetails", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = (ds.Tables[0]);
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {                       
            name();
            bname();
            descripition();
            if (uname == 1 && aname == 1 && desc == 1)
            {
                datainserted();
            }
            else
            {
                MessageBox.Show("Data Not Inserted Try again later...");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var row = dataGridView1.CurrentRow;
            textBox1.Text = row.Cells[0].Value.ToString();
            textBox2.Text = row.Cells[1].Value.ToString();
            textBox3.Text = row.Cells[2].Value.ToString();
            textBox4.Text = row.Cells[3].Value.ToString();
            button3.Enabled = false;
            button1.Enabled = false;
            button4.Enabled = true;
            button5.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update bookdetails set BookName='" + textBox2.Text + "',AuthorName='" + textBox3.Text + "',Descripition='"+textBox4.Text+"'Where BookId='" + textBox1.Text + "'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Congruation data updated...");
            con.Close();
            SqlDataAdapter da = new SqlDataAdapter("select * from bookdetails", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = (ds.Tables[0]);
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from bookdetails Where BookId='"+textBox1.Text+"'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Deleted...");
            con.Close();
            SqlDataAdapter da = new SqlDataAdapter("select * from bookdetails", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = (ds.Tables[0]);
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        void name()
        {
            string text = textBox2.Text;
            Match username = Regex.Match(text, @"^[a-z A-Z 0-9]*$", RegexOptions.IgnoreCase);
            if (username.Success)
            {
                uname++;
            }
            else
            {
                MessageBox.Show("Please Enter Valid User Name");
            }
        }
        void bname()
        {
            string text = textBox3.Text;
            Match username = Regex.Match(text, @"^[a-z A-Z]*$", RegexOptions.IgnoreCase);
            if (username.Success)
            {
                //MessageBox.Show("User Name passed if wala part hai");
                aname++;
            }
            else
            {
                MessageBox.Show("Please Enter Valid Author Name");
            }
        }
        void descripition()
        {
            string text = textBox4.Text;
            Match username = Regex.Match(text, @"^[a-z A-Z 0-9 .,-]*$", RegexOptions.IgnoreCase);
            if (username.Success)
            {
                desc++;
            }
            else
            {
                MessageBox.Show("Please Enter Valid Descripition");
            }
        }
        void datainserted()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into bookdetails values('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Inserted");
            SqlDataAdapter da = new SqlDataAdapter("select * from bookdetails", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = (ds.Tables[0]);
            con.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }
    }
}
