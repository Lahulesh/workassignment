﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace SecondAssignment
{
    public partial class UserAccount : Form
    {
        int u = 0;
        int email = 0;
        int c = 0;
        int a = 0;
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=BookLibrary;Integrated Security=True");
        public UserAccount()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            name();//u
            useremail();//e
            contact();//c
            address();//a
            if (u == 1 && c == 1 && email == 1 && a == 1)
            {
                inserted();
            }
            else
            {
                MessageBox.Show("Data Not Inserted Try again later...");
            }
            void useremail()
            {
                int status = ValidateEmailId(textBox3.Text);
                if (status == 0)
                {
                    MessageBox.Show("Please Enter Valid E-Mail Id", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (status == 1)
                {
                    //MessageBox.Show("Thanks for ptoviding a valid E-mail Id. ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    email++;
                }
                else if (status == 2)
                {
                    MessageBox.Show("Please enter E-mail Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            button3.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UserAccount_Load(object sender, EventArgs e)
        {
            button5.Enabled = false;
            button4.Enabled = false;
            textBox1.Enabled = false;
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from studentdetails", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = (ds.Tables[0]);
            con.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var row = dataGridView1.CurrentRow;
            textBox1.Text = row.Cells[0].Value.ToString();
            textBox2.Text = row.Cells[1].Value.ToString();
            textBox3.Text = row.Cells[2].Value.ToString();
            textBox4.Text = row.Cells[3].Value.ToString();
            textBox5.Text = row.Cells[4].Value.ToString();
            button4.Enabled = true;
            button3.Enabled = false;
            button1.Enabled = false;
            button5.Enabled = true;
        }//Grid View

        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update studentdetails set UserName='" + textBox2.Text + "',EmailId='" + textBox3.Text + "',Contact='" + Convert.ToInt64(textBox4.Text) + "',Address='" + textBox5.Text + "'Where UserId='" + textBox1.Text + "'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Congruation data updated...");
            con.Close();
            Adapter();
        }//Update Code

        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from studentdetails Where UserId='" + textBox1.Text + "'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Deleted...");
            con.Close();
            Adapter();
        }//Detele Code
        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar)&&(e.KeyChar !=(char)(Keys.Back)))
            {
                e.Handled = true;
            }
            else
            {
                if(Char.IsDigit(e.KeyChar))
                {
                    if(textBox4.Text.Length > 9)
                    {
                        e.Handled = true;
                    }
                }
            }
        }
        void contact()
        {
            Regex rg = new Regex("/{10}");
            if(rg.IsMatch(textBox4.Text))
            {
                c++;
            }
            else
            {
                //MessageBox.Show("Enter 10 Digit value number");
                c++;
            }
            
        }
        public int ValidateEmailId(string emailId)
        {
            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
            if (emailId.Length > 0)
            {
                if (!rEMail.IsMatch(emailId))
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }
            return 2;
        }
        void address()
        {
            string text = textBox5.Text;
            Match match = Regex.Match(text, @"^[a-z A-Z 0-9,-]*$", RegexOptions.IgnoreCase);
            if (match.Success)
            {
                a++;
            }
            else
            {
                MessageBox.Show("Please Enter Valid Address");
            }
        }
        void name()
        {
            string text = textBox2.Text;
            Match username = Regex.Match(text, @"^[a-z A-Z 0-9]*$", RegexOptions.IgnoreCase);
            if (username.Success)
            {
                //MessageBox.Show("User Name passed if wala part hai");
                u++;
            }
            else
            {
                MessageBox.Show("Please Enter Valid User Name");
            }
        }
        void inserted()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into studentdetails values('" + textBox2.Text + "','" + textBox3.Text + "','" + Convert.ToInt64(textBox4.Text) + "','" + textBox5.Text + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Congratulation Data Inserted");
            Adapter();
            con.Close();
        }
        void Adapter()
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from studentdetails", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = (ds.Tables[0]);
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
