use BookLibrary;

create table studentdetails
(
UserId int identity(10,1) primary key not null,
UserName varchar(100),
EmailId varchar(100) unique,
Contact bigint unique,
Address varchar(100)
);
select * from studentdetails;

create table bookdetails
(
BookId int identity(100,1)primary key not null,
BookName varchar(100) unique,
AuthorName varchar(100),
Descripition varchar(200)
)
select * from bookdetails;

create table Allocation
(
AllocationId int identity(1000,1) primary key not null,
UserId int foreign key references studentdetails(UserId),
BookId int foreign key references bookdetails(BookId),
UserName varchar(100),
BookName varchar(100),
IssueDate smalldatetime,
ReturnDate smalldatetime
)
select * from Allocation;

con = new SqlConnection(@"Data Source=.;Initial Catalog=BookLibrary;Integrated Security=True");